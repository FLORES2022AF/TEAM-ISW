﻿Public Class generarReporte

    Private Sub generarReporte_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub tablReportes_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles tablReportes.CellContentClick

    End Sub

    Private Sub iconoGenerarReportePDF_Click(sender As Object, e As EventArgs) Handles iconoGenerarReportePDF.Click

    End Sub

    Private Sub botonGenerarReportePDF_Click(sender As Object, e As EventArgs) Handles botonGenerarReportePDF.Click

    End Sub

    Private Sub botonRegresarAPuntoDeVenta_Click(sender As Object, e As EventArgs) Handles botonRegresarAPuntoDeVenta.Click

    End Sub

End Class