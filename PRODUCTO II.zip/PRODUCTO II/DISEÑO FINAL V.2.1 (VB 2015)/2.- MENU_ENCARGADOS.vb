﻿Public Class menuEncargado

    Private Sub menuEncargado_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub iconoPuntoVenta_E_2_Click(sender As Object, e As EventArgs) Handles iconoPuntoVenta_E_2.Click

    End Sub

    Private Sub botonPuntoDeVenta_E_Click(sender As Object, e As EventArgs) Handles botonPuntoDeVenta_E.Click

    End Sub

    Private Sub iconoGenerarPreLista__E_2_Click(sender As Object, e As EventArgs) Handles iconoGenerarPreLista__E_2.Click

    End Sub

    Private Sub iconoGestionarInventario__E_2_Click(sender As Object, e As EventArgs) Handles iconoGestionarInventario__E_2.Click

    End Sub

    Private Sub botonGestionarInventario_E_Click(sender As Object, e As EventArgs) Handles botonGestionarInventario_E.Click

    End Sub

    Private Sub botonCerrarSesion_E_Click(sender As Object, e As EventArgs) Handles botonCerrarSesion_E.Click

    End Sub

End Class