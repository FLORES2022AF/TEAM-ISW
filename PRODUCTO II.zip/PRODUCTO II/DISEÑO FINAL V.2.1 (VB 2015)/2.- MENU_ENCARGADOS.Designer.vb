﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class menuEncargado
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(menuEncargado))
        Me.iconoGenerarPreLista__E_2 = New FontAwesome.Sharp.IconPictureBox()
        Me.iconoPuntoVenta_E_2 = New FontAwesome.Sharp.IconPictureBox()
        Me.iconoGestionarInventario__E_2 = New FontAwesome.Sharp.IconPictureBox()
        Me.botonPuntoDeVenta_E = New System.Windows.Forms.Button()
        Me.botonGestionarInventario_E = New System.Windows.Forms.Button()
        Me.botonGenerarPrelista_E = New System.Windows.Forms.Button()
        Me.botonCerrarSesion_E = New System.Windows.Forms.Button()
        CType(Me.iconoGenerarPreLista__E_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconoPuntoVenta_E_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconoGestionarInventario__E_2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'iconoGenerarPreLista__E_2
        '
        Me.iconoGenerarPreLista__E_2.BackColor = System.Drawing.Color.White
        Me.iconoGenerarPreLista__E_2.ForeColor = System.Drawing.Color.Black
        Me.iconoGenerarPreLista__E_2.IconChar = FontAwesome.Sharp.IconChar.ListCheck
        Me.iconoGenerarPreLista__E_2.IconColor = System.Drawing.Color.Black
        Me.iconoGenerarPreLista__E_2.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoGenerarPreLista__E_2.IconSize = 26
        Me.iconoGenerarPreLista__E_2.Location = New System.Drawing.Point(621, 203)
        Me.iconoGenerarPreLista__E_2.Name = "iconoGenerarPreLista__E_2"
        Me.iconoGenerarPreLista__E_2.Size = New System.Drawing.Size(26, 26)
        Me.iconoGenerarPreLista__E_2.TabIndex = 29
        Me.iconoGenerarPreLista__E_2.TabStop = False
        '
        'iconoPuntoVenta_E_2
        '
        Me.iconoPuntoVenta_E_2.BackColor = System.Drawing.Color.White
        Me.iconoPuntoVenta_E_2.ForeColor = System.Drawing.Color.Black
        Me.iconoPuntoVenta_E_2.IconChar = FontAwesome.Sharp.IconChar.StoreAlt
        Me.iconoPuntoVenta_E_2.IconColor = System.Drawing.Color.Black
        Me.iconoPuntoVenta_E_2.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoPuntoVenta_E_2.IconSize = 26
        Me.iconoPuntoVenta_E_2.Location = New System.Drawing.Point(200, 156)
        Me.iconoPuntoVenta_E_2.Name = "iconoPuntoVenta_E_2"
        Me.iconoPuntoVenta_E_2.Size = New System.Drawing.Size(26, 26)
        Me.iconoPuntoVenta_E_2.TabIndex = 22
        Me.iconoPuntoVenta_E_2.TabStop = False
        '
        'iconoGestionarInventario__E_2
        '
        Me.iconoGestionarInventario__E_2.BackColor = System.Drawing.Color.White
        Me.iconoGestionarInventario__E_2.ForeColor = System.Drawing.Color.Black
        Me.iconoGestionarInventario__E_2.IconChar = FontAwesome.Sharp.IconChar.FolderTree
        Me.iconoGestionarInventario__E_2.IconColor = System.Drawing.Color.Black
        Me.iconoGestionarInventario__E_2.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoGestionarInventario__E_2.IconSize = 26
        Me.iconoGestionarInventario__E_2.Location = New System.Drawing.Point(200, 253)
        Me.iconoGestionarInventario__E_2.Name = "iconoGestionarInventario__E_2"
        Me.iconoGestionarInventario__E_2.Size = New System.Drawing.Size(26, 26)
        Me.iconoGestionarInventario__E_2.TabIndex = 33
        Me.iconoGestionarInventario__E_2.TabStop = False
        '
        'botonPuntoDeVenta_E
        '
        Me.botonPuntoDeVenta_E.BackColor = System.Drawing.Color.LightSlateGray
        Me.botonPuntoDeVenta_E.Font = New System.Drawing.Font("Californian FB", 11.25!)
        Me.botonPuntoDeVenta_E.ForeColor = System.Drawing.Color.Transparent
        Me.botonPuntoDeVenta_E.Location = New System.Drawing.Point(231, 146)
        Me.botonPuntoDeVenta_E.Name = "botonPuntoDeVenta_E"
        Me.botonPuntoDeVenta_E.Size = New System.Drawing.Size(386, 43)
        Me.botonPuntoDeVenta_E.TabIndex = 36
        Me.botonPuntoDeVenta_E.Text = "PUNTO DE VENTA"
        Me.botonPuntoDeVenta_E.UseVisualStyleBackColor = False
        '
        'botonGestionarInventario_E
        '
        Me.botonGestionarInventario_E.BackColor = System.Drawing.Color.LightSlateGray
        Me.botonGestionarInventario_E.Font = New System.Drawing.Font("Californian FB", 11.25!)
        Me.botonGestionarInventario_E.ForeColor = System.Drawing.Color.Transparent
        Me.botonGestionarInventario_E.Location = New System.Drawing.Point(231, 245)
        Me.botonGestionarInventario_E.Name = "botonGestionarInventario_E"
        Me.botonGestionarInventario_E.Size = New System.Drawing.Size(386, 43)
        Me.botonGestionarInventario_E.TabIndex = 38
        Me.botonGestionarInventario_E.Text = "GESTIONAR INVENTARIO"
        Me.botonGestionarInventario_E.UseVisualStyleBackColor = False
        '
        'botonGenerarPrelista_E
        '
        Me.botonGenerarPrelista_E.BackColor = System.Drawing.Color.LightSlateGray
        Me.botonGenerarPrelista_E.Font = New System.Drawing.Font("Californian FB", 11.25!)
        Me.botonGenerarPrelista_E.ForeColor = System.Drawing.Color.White
        Me.botonGenerarPrelista_E.Location = New System.Drawing.Point(231, 195)
        Me.botonGenerarPrelista_E.Name = "botonGenerarPrelista_E"
        Me.botonGenerarPrelista_E.Size = New System.Drawing.Size(386, 43)
        Me.botonGenerarPrelista_E.TabIndex = 37
        Me.botonGenerarPrelista_E.Text = "GENERAR PRE LISTA DE PRODUCTOS"
        Me.botonGenerarPrelista_E.UseVisualStyleBackColor = False
        '
        'botonCerrarSesion_E
        '
        Me.botonCerrarSesion_E.AutoSize = True
        Me.botonCerrarSesion_E.BackColor = System.Drawing.Color.DarkSlateGray
        Me.botonCerrarSesion_E.Font = New System.Drawing.Font("Californian FB", 15.0!)
        Me.botonCerrarSesion_E.ForeColor = System.Drawing.Color.White
        Me.botonCerrarSesion_E.Location = New System.Drawing.Point(636, 485)
        Me.botonCerrarSesion_E.Name = "botonCerrarSesion_E"
        Me.botonCerrarSesion_E.Size = New System.Drawing.Size(171, 34)
        Me.botonCerrarSesion_E.TabIndex = 39
        Me.botonCerrarSesion_E.Text = "CERRAR SESIÓN"
        Me.botonCerrarSesion_E.UseVisualStyleBackColor = False
        '
        'menuEncargado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(819, 531)
        Me.Controls.Add(Me.botonCerrarSesion_E)
        Me.Controls.Add(Me.botonGestionarInventario_E)
        Me.Controls.Add(Me.botonGenerarPrelista_E)
        Me.Controls.Add(Me.botonPuntoDeVenta_E)
        Me.Controls.Add(Me.iconoGestionarInventario__E_2)
        Me.Controls.Add(Me.iconoGenerarPreLista__E_2)
        Me.Controls.Add(Me.iconoPuntoVenta_E_2)
        Me.DoubleBuffered = True
        Me.Name = "menuEncargado"
        Me.Text = "MENU ENCARGADOS"
        CType(Me.iconoGenerarPreLista__E_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconoPuntoVenta_E_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconoGestionarInventario__E_2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents iconoGenerarPreLista__E_2 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents iconoPuntoVenta_E_2 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents iconoGestionarInventario__E_2 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents botonPuntoDeVenta_E As Button
    Friend WithEvents botonGestionarInventario_E As Button
    Friend WithEvents botonGenerarPrelista_E As Button
    Friend WithEvents botonCerrarSesion_E As Button
End Class
