﻿Public Class puntoDeVenta

    Private Sub puntoDeVenta_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub buscadorDeArticulos_TextChanged(sender As Object, e As EventArgs) Handles buscadorDeArticulos.TextChanged

    End Sub

    Private Sub botonManejoCantidad_SelectedItemChanged(sender As Object, e As EventArgs) Handles botonManejoCantidad.SelectedItemChanged

    End Sub

    Private Sub iconoBuscarArticulo_Click(sender As Object, e As EventArgs) Handles iconoBuscarArticulo.Click

    End Sub

    Private Sub botonBuscarArticulos_Click(sender As Object, e As EventArgs) Handles botonBuscarArticulos.Click

    End Sub

    Private Sub tablaBusquedaDeArticulos_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles tablaBusquedaDeArticulos.CellContentClick

    End Sub

    Private Sub botonGenerarReporte_Click(sender As Object, e As EventArgs) Handles botonGenerarReporte.Click

    End Sub

    Private Sub botonGenerarVenta_Click(sender As Object, e As EventArgs) Handles botonGenerarVenta.Click

    End Sub

    Private Sub botonEliminaArticulos_Click(sender As Object, e As EventArgs) Handles botonEliminaArticulos.Click

    End Sub

    Private Sub botonRegresarAMenu_D_O_E_Click(sender As Object, e As EventArgs) Handles botonRegresarAMenu_D_O_E.Click

    End Sub

End Class