Imports Oracle.DataAccess.Client
Public Class gestionarUsuario

    Public Sub InsertarUsuario()
        'Dim sqlcmd As New OracleCommand("INSERT INTO usuarios (id,correo,password) VALUES  (2,'sd','asd@s.com')", Cone)

        Dim command As New OracleCommand
        command.Connection = Cone
        'Cone.BeginTransaction()


        Try
            command.CommandText = "INSERT  INTO Usuarios VALUES (" & ingreseId.Text & "','" & ingreseNombreUsuario.Text & "','" & ingreseApellidoPaternoUsuario.Text & "','" & ingreseApellidoMaternoUsuario.Text & "','" & ingreseUsuario.Text & "','" & ingreseClave.Text & "','" & ingreseTipodeUsuario.Text & "')"
            command.ExecuteNonQuery()
            MsgBox("Usuario creado con exito")

        Catch ex As Exception
            MsgBox(ex.ToString)
            'Throw New Exception("Error: " & ex.Message)
            If (ex.ToString.Contains("unique")) Then
                MsgBox("Llave Primaria Duplicada")
            End If
            If (ex.ToString.Contains("missing" Or "NULL")) Then
                MsgBox("No se puede insertar, existen campos vacios")
            End If

        End Try

    End Sub

    Private Sub gestionarUsuario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    private sub Modificar_usuario()
    Dim command As New OracleCommand
        command.Connection = Cone
        'Cone.BeginTransaction()


        Try
            command.CommandText = "UPDATE tabla set nombre =" & ingreseNombreUsuario.Text &", paterno = ?, materno = ?, usuario = ?, clave = ?, tipodeUsuario = " & ingreseId.Text & "','" & ingreseNombreUsuario.Text & "','" & ingreseApellidoPaternoUsuario.Text & "','" & ingreseApellidoMaternoUsuario.Text & "','" & ingreseUsuario.Text & "','" & ingreseClave.Text & "','" & ingreseTipodeUsuario.Text & "')"
            
            MsgBox("Usuario creado con exito")

        Catch ex As Exception
            MsgBox(ex.ToString)
            'Throw New Exception("Error: " & ex.Message)
            If (ex.ToString.Contains("unique")) Then
                MsgBox("Llave Primaria Duplicada")
            End If
            If (ex.ToString.Contains("missing" Or "NULL")) Then
                MsgBox("No se puede insertar, existen campos vacios")
            End If

        End Try
    End Sub

    Private Sub gestionarUsuario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub
    


    Private Sub buscadorDeUsuarios_TextChanged(sender As Object, e As EventArgs) Handles buscadorDeUsuarios.TextChanged

    End Sub

    Private Sub iconoBuscarUsuario_Click(sender As Object, e As EventArgs) Handles iconoBuscarUsuario.Click

    End Sub

    Private Sub botonBuscarUsuario_Click(sender As Object, e As EventArgs) Handles botonBuscarUsuario.Click

    End Sub

    Private Sub etiquetaNombreUsuario_Click(sender As Object, e As EventArgs) Handles etiquetaNombreUsuario.Click

    End Sub

    Private Sub ingreseNombreUsuario_TextChanged(sender As Object, e As EventArgs) Handles ingreseNombreUsuario.TextChanged

    End Sub

    Private Sub etiquetaApellidoPaternoUsuario_Click(sender As Object, e As EventArgs) Handles etiquetaApellidoPaternoUsuario.Click

    End Sub

    Private Sub ingreseApellidoPaternoUsuario_TextChanged(sender As Object, e As EventArgs) Handles ingreseApellidoPaternoUsuario.TextChanged

    End Sub

    Private Sub etiquetaApellidoMaternoUsuario_Click(sender As Object, e As EventArgs) Handles etiquetaApellidoMaternoUsuario.Click

    End Sub

    Private Sub ingreseApellidoMaternoUsuario_TextChanged(sender As Object, e As EventArgs) Handles ingreseApellidoMaternoUsuario.TextChanged

    End Sub

    Private Sub etiquetaUsuario_GU_Click(sender As Object, e As EventArgs) Handles etiquetaUsuario_GU.Click

    End Sub

    Private Sub ingreseUsuario_TextChanged(sender As Object, e As EventArgs) Handles ingreseUsuario.TextChanged

    End Sub

    Private Sub botonDarDeAltaUsuario_Click(sender As Object, e As EventArgs) Handles botonDarDeAltaUsuario.Click
        InsertarUsuario()
        MsgBox("Usuario creado con exito")
    End Sub

    Private Sub botonModificarUsuario_Click(sender As Object, e As EventArgs) Handles botonModificarUsuario.Click
        MsgBox("Usuario modificado con exito")
    End Sub

    Private Sub botonBorrarUsuario_Click(sender As Object, e As EventArgs) Handles botonBorrarUsuario.Click
        MsgBox("Usuario borrado con exito")
    End Sub

    Private Sub botonRegresarAGenerarReporte_Click(sender As Object, e As EventArgs) Handles botonRegresarAGenerarReporte.Click
        menuDueno.Show()
        Me.Close()
    End Sub

    Private Sub clave_Click(sender As Object, e As EventArgs) Handles clave.Click

    End Sub

    Private Sub ingreseClave_TextChanged(sender As Object, e As EventArgs) Handles ingreseClave.TextChanged

    End Sub

    Private Sub ingreseId_TextChanged(sender As Object, e As EventArgs) Handles ingreseId.TextChanged

    End Sub

    Private Sub TUsuario_Click(sender As Object, e As EventArgs) Handles tipoUsuario.Click

    End Sub
Private Sub ingreseTipodeUsuario_TextChanged(sender As Object, e As EventArgs) Handles ingreseTipodeUsuario.TextChanged

    End Sub
End Class