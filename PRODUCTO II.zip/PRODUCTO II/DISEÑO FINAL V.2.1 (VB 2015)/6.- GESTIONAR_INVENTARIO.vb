﻿Public Class gestionarInventario
    Private Sub gestionarInventario_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub buscadorDeProductos_TextChanged(sender As Object, e As EventArgs) Handles buscadorDeProductos.TextChanged

    End Sub

    Private Sub botonManejoCantidad_SelectedItemChanged(sender As Object, e As EventArgs) Handles botonManejoCantidad.SelectedItemChanged

    End Sub

    Private Sub iconoBuscarArt_Click(sender As Object, e As EventArgs) Handles iconoBuscarArt.Click

    End Sub

    Private Sub botonBuscarArticulos_Click(sender As Object, e As EventArgs) Handles botonBuscarArticulos.Click

    End Sub

    Private Sub ingreseIDArticulo_TextChanged(sender As Object, e As EventArgs) Handles ingreseIDArticulo.TextChanged

    End Sub

    Private Sub ingreseNombreDelArticulo_TextChanged(sender As Object, e As EventArgs) Handles ingreseNombreDelArticulo.TextChanged

    End Sub

    Private Sub ingresePrecioDelArticulo_TextChanged(sender As Object, e As EventArgs) Handles ingresePrecioDelArticulo.TextChanged

    End Sub

    Private Sub ingreseCantidadDeSeguridad_TextChanged(sender As Object, e As EventArgs) Handles ingreseCantidadDeSeguridad.TextChanged

    End Sub

    Private Sub ingreseCantidadActual_TextChanged(sender As Object, e As EventArgs) Handles ingreseCantidadActual.TextChanged

    End Sub

    Private Sub tablaDeProductosInventario_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles tablaDeProductosInventario.CellContentClick

    End Sub

    Private Sub botonDarDeAltaArticulo_Click(sender As Object, e As EventArgs) Handles botonDarDeAltaArticulo.Click

    End Sub

    Private Sub botonModificarArticulo_Click(sender As Object, e As EventArgs) Handles botonModificarArticulo.Click

    End Sub

    Private Sub botonBorrarArticulo_Click(sender As Object, e As EventArgs) Handles botonBorrarArticulo.Click

    End Sub

    Private Sub botonRegresarAGestionarUsuario_Click(sender As Object, e As EventArgs) Handles botonRegresarAGestionarUsuario.Click

    End Sub

End Class