﻿Public Class menuDueno
    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub botonGenerarPrelistaDeProductos_Click(sender As Object, e As EventArgs) Handles botonGenerarPrelistaDeProductos_D.Click

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub botonPuntoDeVenta_D_Click(sender As Object, e As EventArgs) Handles botonPuntoDeVenta_D.Click

    End Sub
End Class