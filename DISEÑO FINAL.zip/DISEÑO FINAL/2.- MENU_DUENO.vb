﻿Public Class menuDueno
    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub botonGenerarPrelistaDeProductos_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub botonPuntoDeVenta_D_Click(sender As Object, e As EventArgs) Handles botonPuntoDeVenta_D.Click

    End Sub

    Private Sub botonGestionarInventario_D_Click(sender As Object, e As EventArgs) Handles botonGestionarInventario_D.Click

    End Sub

    Private Sub iconoPuntoVenta_D_1_Click(sender As Object, e As EventArgs) Handles iconoPuntoVenta_D_1.Click

    End Sub

    Private Sub iconoPuntoVenta_D_2_Click(sender As Object, e As EventArgs) Handles iconoPuntoVenta_D_2.Click

    End Sub

    Private Sub botonGestionarUsuario_D_Click(sender As Object, e As EventArgs) Handles botonGestionarUsuario_D.Click

    End Sub

    Private Sub iconoGestionarUsuario_1_Click(sender As Object, e As EventArgs) Handles iconoGestionarUsuario_1.Click

    End Sub

    Private Sub iconoGestionarUsuario_2_Click(sender As Object, e As EventArgs) Handles iconoGestionarUsuario_D_1.Click

    End Sub

    Private Sub iconoGenerarPreLista__D_2_Click(sender As Object, e As EventArgs) Handles iconoGenerarPreLista__D_1.Click

    End Sub

    Private Sub iconoGenerarPreLista__D_1_Click(sender As Object, e As EventArgs) Handles iconoGenerarPreLista__D_1.Click

    End Sub

    Private Sub iconoGestionarInventario__D_2_Click(sender As Object, e As EventArgs) Handles iconoGestionarInventario__D_2.Click

    End Sub

    Private Sub iconoGestionarInventario__D_1_Click(sender As Object, e As EventArgs) Handles iconoGestionarInventario__D_1.Click

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles botonGenerarPrelista_D.Click

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles botonGestionarUsuario_D.Click

    End Sub
End Class