﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class gestionarInventario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(gestionarInventario))
        Me.tituloGestionarInventario = New System.Windows.Forms.Label()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.iconoBuscarArt = New FontAwesome.Sharp.IconPictureBox()
        Me.buscadorDeProductos = New System.Windows.Forms.TextBox()
        Me.ingreseIDArticulo = New System.Windows.Forms.TextBox()
        Me.ingreseNombreDelArticulo = New System.Windows.Forms.TextBox()
        Me.ingresePrecioDelArticulo = New System.Windows.Forms.TextBox()
        Me.ingreseCantidadActual = New System.Windows.Forms.TextBox()
        Me.ingreseCantidadDeSeguridad = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.barraDeslizante3 = New System.Windows.Forms.VScrollBar()
        Me.botonRegresar_E_D1 = New System.Windows.Forms.Button()
        Me.botonModificarArticulo = New System.Windows.Forms.Button()
        Me.botonBorrarArticulo = New System.Windows.Forms.Button()
        Me.id__Articulo_Tabla_Gestionar_Inventario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.nombre_Articulo_Gestionar_Inventario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.precio_Articulo_Tabla_Gestionar_Inventario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cantidad_Seguridad_Tabla_Gestionar_Inventario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cantidad_Actual_Tabla_Gestionar_Inventario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.iconoBuscarArt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tituloGestionarInventario
        '
        Me.tituloGestionarInventario.BackColor = System.Drawing.Color.Transparent
        Me.tituloGestionarInventario.Font = New System.Drawing.Font("Agency FB", 30.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.tituloGestionarInventario.ForeColor = System.Drawing.Color.White
        Me.tituloGestionarInventario.Location = New System.Drawing.Point(228, 9)
        Me.tituloGestionarInventario.Name = "tituloGestionarInventario"
        Me.tituloGestionarInventario.Size = New System.Drawing.Size(364, 63)
        Me.tituloGestionarInventario.TabIndex = 15
        Me.tituloGestionarInventario.Text = "GESTIONAR INVENTARIO"
        Me.tituloGestionarInventario.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'botonAceptar
        '
        Me.botonAceptar.AutoSize = True
        Me.botonAceptar.BackColor = System.Drawing.Color.Black
        Me.botonAceptar.Font = New System.Drawing.Font("Agency FB", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.botonAceptar.ForeColor = System.Drawing.Color.White
        Me.botonAceptar.Location = New System.Drawing.Point(692, 65)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(81, 34)
        Me.botonAceptar.TabIndex = 20
        Me.botonAceptar.Text = "ACEPTAR"
        Me.botonAceptar.UseVisualStyleBackColor = False
        '
        'iconoBuscarArt
        '
        Me.iconoBuscarArt.BackColor = System.Drawing.Color.Transparent
        Me.iconoBuscarArt.IconChar = FontAwesome.Sharp.IconChar.Search
        Me.iconoBuscarArt.IconColor = System.Drawing.Color.White
        Me.iconoBuscarArt.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoBuscarArt.IconSize = 23
        Me.iconoBuscarArt.Location = New System.Drawing.Point(651, 75)
        Me.iconoBuscarArt.Name = "iconoBuscarArt"
        Me.iconoBuscarArt.Size = New System.Drawing.Size(23, 23)
        Me.iconoBuscarArt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.iconoBuscarArt.TabIndex = 19
        Me.iconoBuscarArt.TabStop = False
        '
        'buscadorDeProductos
        '
        Me.buscadorDeProductos.Location = New System.Drawing.Point(36, 75)
        Me.buscadorDeProductos.Name = "buscadorDeProductos"
        Me.buscadorDeProductos.Size = New System.Drawing.Size(638, 23)
        Me.buscadorDeProductos.TabIndex = 18
        Me.buscadorDeProductos.Text = "Buscar producto"
        '
        'ingreseIDArticulo
        '
        Me.ingreseIDArticulo.Location = New System.Drawing.Point(36, 124)
        Me.ingreseIDArticulo.Name = "ingreseIDArticulo"
        Me.ingreseIDArticulo.Size = New System.Drawing.Size(81, 23)
        Me.ingreseIDArticulo.TabIndex = 21
        Me.ingreseIDArticulo.Text = "ID_Articulo"
        '
        'ingreseNombreDelArticulo
        '
        Me.ingreseNombreDelArticulo.Location = New System.Drawing.Point(132, 124)
        Me.ingreseNombreDelArticulo.Name = "ingreseNombreDelArticulo"
        Me.ingreseNombreDelArticulo.Size = New System.Drawing.Size(99, 23)
        Me.ingreseNombreDelArticulo.TabIndex = 22
        Me.ingreseNombreDelArticulo.Text = "Nombre_Articulo"
        '
        'ingresePrecioDelArticulo
        '
        Me.ingresePrecioDelArticulo.Location = New System.Drawing.Point(244, 124)
        Me.ingresePrecioDelArticulo.Name = "ingresePrecioDelArticulo"
        Me.ingresePrecioDelArticulo.Size = New System.Drawing.Size(87, 23)
        Me.ingresePrecioDelArticulo.TabIndex = 23
        Me.ingresePrecioDelArticulo.Text = "Precio_Articulo"
        '
        'ingreseCantidadActual
        '
        Me.ingreseCantidadActual.Location = New System.Drawing.Point(481, 124)
        Me.ingreseCantidadActual.Name = "ingreseCantidadActual"
        Me.ingreseCantidadActual.Size = New System.Drawing.Size(134, 23)
        Me.ingreseCantidadActual.TabIndex = 24
        Me.ingreseCantidadActual.Text = "Cant._Actual_Producto"
        '
        'ingreseCantidadDeSeguridad
        '
        Me.ingreseCantidadDeSeguridad.Location = New System.Drawing.Point(344, 124)
        Me.ingreseCantidadDeSeguridad.Multiline = True
        Me.ingreseCantidadDeSeguridad.Name = "ingreseCantidadDeSeguridad"
        Me.ingreseCantidadDeSeguridad.Size = New System.Drawing.Size(123, 23)
        Me.ingreseCantidadDeSeguridad.TabIndex = 25
        Me.ingreseCantidadDeSeguridad.Text = "Cantidad_Seguridad"
        '
        'Button1
        '
        Me.Button1.AutoSize = True
        Me.Button1.BackColor = System.Drawing.Color.Black
        Me.Button1.Font = New System.Drawing.Font("Agency FB", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(632, 114)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(146, 34)
        Me.Button1.TabIndex = 26
        Me.Button1.Text = "DAR DE ALTA ARTICULO"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.id__Articulo_Tabla_Gestionar_Inventario, Me.nombre_Articulo_Gestionar_Inventario, Me.precio_Articulo_Tabla_Gestionar_Inventario, Me.cantidad_Seguridad_Tabla_Gestionar_Inventario, Me.cantidad_Actual_Tabla_Gestionar_Inventario})
        Me.DataGridView1.Location = New System.Drawing.Point(36, 171)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 25
        Me.DataGridView1.Size = New System.Drawing.Size(742, 241)
        Me.DataGridView1.TabIndex = 27
        '
        'barraDeslizante3
        '
        Me.barraDeslizante3.Location = New System.Drawing.Point(756, 220)
        Me.barraDeslizante3.Name = "barraDeslizante3"
        Me.barraDeslizante3.Size = New System.Drawing.Size(17, 181)
        Me.barraDeslizante3.TabIndex = 28
        '
        'botonRegresar_E_D1
        '
        Me.botonRegresar_E_D1.AutoSize = True
        Me.botonRegresar_E_D1.BackColor = System.Drawing.Color.Black
        Me.botonRegresar_E_D1.Font = New System.Drawing.Font("Agency FB", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.botonRegresar_E_D1.ForeColor = System.Drawing.Color.White
        Me.botonRegresar_E_D1.Location = New System.Drawing.Point(12, 495)
        Me.botonRegresar_E_D1.Name = "botonRegresar_E_D1"
        Me.botonRegresar_E_D1.Size = New System.Drawing.Size(81, 34)
        Me.botonRegresar_E_D1.TabIndex = 29
        Me.botonRegresar_E_D1.Text = "REGRESAR"
        Me.botonRegresar_E_D1.UseVisualStyleBackColor = False
        '
        'botonModificarArticulo
        '
        Me.botonModificarArticulo.AutoSize = True
        Me.botonModificarArticulo.BackColor = System.Drawing.Color.Black
        Me.botonModificarArticulo.Font = New System.Drawing.Font("Agency FB", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.botonModificarArticulo.ForeColor = System.Drawing.Color.White
        Me.botonModificarArticulo.Location = New System.Drawing.Point(36, 422)
        Me.botonModificarArticulo.Name = "botonModificarArticulo"
        Me.botonModificarArticulo.Size = New System.Drawing.Size(370, 67)
        Me.botonModificarArticulo.TabIndex = 30
        Me.botonModificarArticulo.Text = "MODIFICAR ARTICULO"
        Me.botonModificarArticulo.UseVisualStyleBackColor = False
        '
        'botonBorrarArticulo
        '
        Me.botonBorrarArticulo.AutoSize = True
        Me.botonBorrarArticulo.BackColor = System.Drawing.Color.Black
        Me.botonBorrarArticulo.Font = New System.Drawing.Font("Agency FB", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.botonBorrarArticulo.ForeColor = System.Drawing.Color.White
        Me.botonBorrarArticulo.Location = New System.Drawing.Point(408, 422)
        Me.botonBorrarArticulo.Name = "botonBorrarArticulo"
        Me.botonBorrarArticulo.Size = New System.Drawing.Size(370, 67)
        Me.botonBorrarArticulo.TabIndex = 31
        Me.botonBorrarArticulo.Text = "BORRAR ARTICULO"
        Me.botonBorrarArticulo.UseVisualStyleBackColor = False
        '
        'id__Articulo_Tabla_Gestionar_Inventario
        '
        Me.id__Articulo_Tabla_Gestionar_Inventario.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.id__Articulo_Tabla_Gestionar_Inventario.FillWeight = 35.0!
        Me.id__Articulo_Tabla_Gestionar_Inventario.HeaderText = "ID_ARTICULO"
        Me.id__Articulo_Tabla_Gestionar_Inventario.Name = "id__Articulo_Tabla_Gestionar_Inventario"
        Me.id__Articulo_Tabla_Gestionar_Inventario.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'nombre_Articulo_Gestionar_Inventario
        '
        Me.nombre_Articulo_Gestionar_Inventario.HeaderText = "NOMBRE_ARTICULO"
        Me.nombre_Articulo_Gestionar_Inventario.Name = "nombre_Articulo_Gestionar_Inventario"
        '
        'precio_Articulo_Tabla_Gestionar_Inventario
        '
        Me.precio_Articulo_Tabla_Gestionar_Inventario.HeaderText = "PRECIO_ARTICULO"
        Me.precio_Articulo_Tabla_Gestionar_Inventario.Name = "precio_Articulo_Tabla_Gestionar_Inventario"
        '
        'cantidad_Seguridad_Tabla_Gestionar_Inventario
        '
        Me.cantidad_Seguridad_Tabla_Gestionar_Inventario.HeaderText = "CANTIDAD_SEGURIDAD"
        Me.cantidad_Seguridad_Tabla_Gestionar_Inventario.Name = "cantidad_Seguridad_Tabla_Gestionar_Inventario"
        '
        'cantidad_Actual_Tabla_Gestionar_Inventario
        '
        Me.cantidad_Actual_Tabla_Gestionar_Inventario.HeaderText = "CANTIDAD_ACTUAL_PRODUCTO"
        Me.cantidad_Actual_Tabla_Gestionar_Inventario.Name = "cantidad_Actual_Tabla_Gestionar_Inventario"
        '
        'gestionarInventario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(814, 541)
        Me.Controls.Add(Me.botonBorrarArticulo)
        Me.Controls.Add(Me.botonModificarArticulo)
        Me.Controls.Add(Me.botonRegresar_E_D1)
        Me.Controls.Add(Me.barraDeslizante3)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ingreseCantidadDeSeguridad)
        Me.Controls.Add(Me.ingreseCantidadActual)
        Me.Controls.Add(Me.ingresePrecioDelArticulo)
        Me.Controls.Add(Me.ingreseNombreDelArticulo)
        Me.Controls.Add(Me.ingreseIDArticulo)
        Me.Controls.Add(Me.botonAceptar)
        Me.Controls.Add(Me.iconoBuscarArt)
        Me.Controls.Add(Me.buscadorDeProductos)
        Me.Controls.Add(Me.tituloGestionarInventario)
        Me.Name = "gestionarInventario"
        Me.Text = "GESTIONAR INVENTARIO"
        CType(Me.iconoBuscarArt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tituloGestionarInventario As Label
    Friend WithEvents botonAceptar As Button
    Friend WithEvents iconoBuscarArt As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents buscadorDeProductos As TextBox
    Friend WithEvents ingreseIDArticulo As TextBox
    Friend WithEvents ingreseNombreDelArticulo As TextBox
    Friend WithEvents ingresePrecioDelArticulo As TextBox
    Friend WithEvents ingreseCantidadActual As TextBox
    Friend WithEvents ingreseCantidadDeSeguridad As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents barraDeslizante3 As VScrollBar
    Friend WithEvents botonRegresar_E_D1 As Button
    Friend WithEvents id__Articulo_Tabla_Gestionar_Inventario As DataGridViewTextBoxColumn
    Friend WithEvents nombre_Articulo_Gestionar_Inventario As DataGridViewTextBoxColumn
    Friend WithEvents precio_Articulo_Tabla_Gestionar_Inventario As DataGridViewTextBoxColumn
    Friend WithEvents cantidad_Seguridad_Tabla_Gestionar_Inventario As DataGridViewTextBoxColumn
    Friend WithEvents cantidad_Actual_Tabla_Gestionar_Inventario As DataGridViewTextBoxColumn
    Friend WithEvents botonModificarArticulo As Button
    Friend WithEvents botonBorrarArticulo As Button
End Class
