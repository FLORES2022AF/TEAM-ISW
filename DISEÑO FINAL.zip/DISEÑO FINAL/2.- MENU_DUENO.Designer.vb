﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class menuDueno
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(menuDueno))
        Me.botonPuntoDeVenta_D = New System.Windows.Forms.Button()
        Me.botonGestionarUsuario_D = New System.Windows.Forms.Button()
        Me.botonGestionarInventario_D = New System.Windows.Forms.Button()
        Me.botonGenerarPrelistaDeProductos_D = New System.Windows.Forms.Button()
        Me.botonRegresar_D_L0 = New System.Windows.Forms.Button()
        Me.tituloMenuDueno = New System.Windows.Forms.Label()
        Me.iconoPuntoVenta_D_1 = New FontAwesome.Sharp.IconPictureBox()
        Me.IconPictureBox1 = New FontAwesome.Sharp.IconPictureBox()
        Me.iconoPuntoVenta_D_2 = New FontAwesome.Sharp.IconPictureBox()
        Me.iconoGestionarUsuario_1 = New FontAwesome.Sharp.IconPictureBox()
        Me.iconoGestionarUsuario_2 = New FontAwesome.Sharp.IconPictureBox()
        Me.iconoGestionarInventario__D_1 = New FontAwesome.Sharp.IconPictureBox()
        Me.iconoGestionarInventario__D_2 = New FontAwesome.Sharp.IconPictureBox()
        Me.iconoGenerarPreLista__D_1 = New FontAwesome.Sharp.IconPictureBox()
        Me.iconoGenerarPreLista__D_2 = New FontAwesome.Sharp.IconPictureBox()
        CType(Me.iconoPuntoVenta_D_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IconPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconoPuntoVenta_D_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconoGestionarUsuario_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconoGestionarUsuario_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconoGestionarInventario__D_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconoGestionarInventario__D_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconoGenerarPreLista__D_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconoGenerarPreLista__D_2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'botonPuntoDeVenta_D
        '
        Me.botonPuntoDeVenta_D.BackColor = System.Drawing.Color.Black
        Me.botonPuntoDeVenta_D.Font = New System.Drawing.Font("Agency FB", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.botonPuntoDeVenta_D.ForeColor = System.Drawing.Color.White
        Me.botonPuntoDeVenta_D.Location = New System.Drawing.Point(211, 151)
        Me.botonPuntoDeVenta_D.Name = "botonPuntoDeVenta_D"
        Me.botonPuntoDeVenta_D.Size = New System.Drawing.Size(186, 139)
        Me.botonPuntoDeVenta_D.TabIndex = 0
        Me.botonPuntoDeVenta_D.Text = "Punto de venta"
        Me.botonPuntoDeVenta_D.UseVisualStyleBackColor = False
        '
        'botonGestionarUsuario_D
        '
        Me.botonGestionarUsuario_D.BackColor = System.Drawing.Color.Black
        Me.botonGestionarUsuario_D.Font = New System.Drawing.Font("Agency FB", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.botonGestionarUsuario_D.ForeColor = System.Drawing.Color.White
        Me.botonGestionarUsuario_D.Location = New System.Drawing.Point(389, 151)
        Me.botonGestionarUsuario_D.Name = "botonGestionarUsuario_D"
        Me.botonGestionarUsuario_D.Size = New System.Drawing.Size(186, 139)
        Me.botonGestionarUsuario_D.TabIndex = 1
        Me.botonGestionarUsuario_D.Text = "Gestionar usuario"
        Me.botonGestionarUsuario_D.UseVisualStyleBackColor = False
        '
        'botonGestionarInventario_D
        '
        Me.botonGestionarInventario_D.BackColor = System.Drawing.Color.Black
        Me.botonGestionarInventario_D.Font = New System.Drawing.Font("Agency FB", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.botonGestionarInventario_D.ForeColor = System.Drawing.Color.White
        Me.botonGestionarInventario_D.Location = New System.Drawing.Point(211, 287)
        Me.botonGestionarInventario_D.Name = "botonGestionarInventario_D"
        Me.botonGestionarInventario_D.Size = New System.Drawing.Size(186, 139)
        Me.botonGestionarInventario_D.TabIndex = 2
        Me.botonGestionarInventario_D.Text = "Gestionar inventario"
        Me.botonGestionarInventario_D.UseVisualStyleBackColor = False
        '
        'botonGenerarPrelistaDeProductos_D
        '
        Me.botonGenerarPrelistaDeProductos_D.BackColor = System.Drawing.Color.Black
        Me.botonGenerarPrelistaDeProductos_D.Font = New System.Drawing.Font("Agency FB", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.botonGenerarPrelistaDeProductos_D.ForeColor = System.Drawing.Color.White
        Me.botonGenerarPrelistaDeProductos_D.Location = New System.Drawing.Point(389, 287)
        Me.botonGenerarPrelistaDeProductos_D.Name = "botonGenerarPrelistaDeProductos_D"
        Me.botonGenerarPrelistaDeProductos_D.Size = New System.Drawing.Size(186, 139)
        Me.botonGenerarPrelistaDeProductos_D.TabIndex = 3
        Me.botonGenerarPrelistaDeProductos_D.Text = "Generar pre lista de productos"
        Me.botonGenerarPrelistaDeProductos_D.UseVisualStyleBackColor = False
        '
        'botonRegresar_D_L0
        '
        Me.botonRegresar_D_L0.AutoSize = True
        Me.botonRegresar_D_L0.BackColor = System.Drawing.Color.Black
        Me.botonRegresar_D_L0.Font = New System.Drawing.Font("Agency FB", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.botonRegresar_D_L0.ForeColor = System.Drawing.Color.White
        Me.botonRegresar_D_L0.Location = New System.Drawing.Point(12, 495)
        Me.botonRegresar_D_L0.Name = "botonRegresar_D_L0"
        Me.botonRegresar_D_L0.Size = New System.Drawing.Size(81, 34)
        Me.botonRegresar_D_L0.TabIndex = 5
        Me.botonRegresar_D_L0.Text = "REGRESAR"
        Me.botonRegresar_D_L0.UseVisualStyleBackColor = False
        '
        'tituloMenuDueno
        '
        Me.tituloMenuDueno.BackColor = System.Drawing.Color.Transparent
        Me.tituloMenuDueno.Font = New System.Drawing.Font("Agency FB", 30.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.tituloMenuDueno.ForeColor = System.Drawing.Color.White
        Me.tituloMenuDueno.Location = New System.Drawing.Point(211, 9)
        Me.tituloMenuDueno.Name = "tituloMenuDueno"
        Me.tituloMenuDueno.Size = New System.Drawing.Size(364, 121)
        Me.tituloMenuDueno.TabIndex = 4
        Me.tituloMenuDueno.Text = "MENÚ PRINCIPAL (DUEÑO)"
        Me.tituloMenuDueno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'iconoPuntoVenta_D_1
        '
        Me.iconoPuntoVenta_D_1.IconChar = FontAwesome.Sharp.IconChar.StoreAlt
        Me.iconoPuntoVenta_D_1.IconColor = System.Drawing.Color.White
        Me.iconoPuntoVenta_D_1.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoPuntoVenta_D_1.IconSize = 29
        Me.iconoPuntoVenta_D_1.Location = New System.Drawing.Point(223, 246)
        Me.iconoPuntoVenta_D_1.Name = "iconoPuntoVenta_D_1"
        Me.iconoPuntoVenta_D_1.Size = New System.Drawing.Size(29, 35)
        Me.iconoPuntoVenta_D_1.TabIndex = 9
        Me.iconoPuntoVenta_D_1.TabStop = False
        '
        'IconPictureBox1
        '
        Me.IconPictureBox1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.IconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconPictureBox1.IconColor = System.Drawing.SystemColors.ControlText
        Me.IconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox1.IconSize = 8
        Me.IconPictureBox1.Location = New System.Drawing.Point(687, 301)
        Me.IconPictureBox1.Name = "IconPictureBox1"
        Me.IconPictureBox1.Size = New System.Drawing.Size(8, 8)
        Me.IconPictureBox1.TabIndex = 10
        Me.IconPictureBox1.TabStop = False
        '
        'iconoPuntoVenta_D_2
        '
        Me.iconoPuntoVenta_D_2.IconChar = FontAwesome.Sharp.IconChar.FileAlt
        Me.iconoPuntoVenta_D_2.IconColor = System.Drawing.Color.White
        Me.iconoPuntoVenta_D_2.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoPuntoVenta_D_2.IconSize = 29
        Me.iconoPuntoVenta_D_2.Location = New System.Drawing.Point(355, 247)
        Me.iconoPuntoVenta_D_2.Name = "iconoPuntoVenta_D_2"
        Me.iconoPuntoVenta_D_2.Size = New System.Drawing.Size(29, 35)
        Me.iconoPuntoVenta_D_2.TabIndex = 11
        Me.iconoPuntoVenta_D_2.TabStop = False
        '
        'iconoGestionarUsuario_1
        '
        Me.iconoGestionarUsuario_1.IconChar = FontAwesome.Sharp.IconChar.FolderPlus
        Me.iconoGestionarUsuario_1.IconColor = System.Drawing.Color.White
        Me.iconoGestionarUsuario_1.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoGestionarUsuario_1.IconSize = 29
        Me.iconoGestionarUsuario_1.Location = New System.Drawing.Point(404, 246)
        Me.iconoGestionarUsuario_1.Name = "iconoGestionarUsuario_1"
        Me.iconoGestionarUsuario_1.Size = New System.Drawing.Size(29, 35)
        Me.iconoGestionarUsuario_1.TabIndex = 12
        Me.iconoGestionarUsuario_1.TabStop = False
        '
        'iconoGestionarUsuario_2
        '
        Me.iconoGestionarUsuario_2.IconChar = FontAwesome.Sharp.IconChar.UserCog
        Me.iconoGestionarUsuario_2.IconColor = System.Drawing.Color.White
        Me.iconoGestionarUsuario_2.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoGestionarUsuario_2.IconSize = 29
        Me.iconoGestionarUsuario_2.Location = New System.Drawing.Point(538, 247)
        Me.iconoGestionarUsuario_2.Name = "iconoGestionarUsuario_2"
        Me.iconoGestionarUsuario_2.Size = New System.Drawing.Size(29, 35)
        Me.iconoGestionarUsuario_2.TabIndex = 13
        Me.iconoGestionarUsuario_2.TabStop = False
        '
        'iconoGestionarInventario__D_1
        '
        Me.iconoGestionarInventario__D_1.IconChar = FontAwesome.Sharp.IconChar.FolderTree
        Me.iconoGestionarInventario__D_1.IconColor = System.Drawing.Color.White
        Me.iconoGestionarInventario__D_1.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoGestionarInventario__D_1.IconSize = 24
        Me.iconoGestionarInventario__D_1.Location = New System.Drawing.Point(223, 301)
        Me.iconoGestionarInventario__D_1.Name = "iconoGestionarInventario__D_1"
        Me.iconoGestionarInventario__D_1.Size = New System.Drawing.Size(29, 24)
        Me.iconoGestionarInventario__D_1.TabIndex = 14
        Me.iconoGestionarInventario__D_1.TabStop = False
        '
        'iconoGestionarInventario__D_2
        '
        Me.iconoGestionarInventario__D_2.IconChar = FontAwesome.Sharp.IconChar.Cog
        Me.iconoGestionarInventario__D_2.IconColor = System.Drawing.Color.White
        Me.iconoGestionarInventario__D_2.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoGestionarInventario__D_2.IconSize = 24
        Me.iconoGestionarInventario__D_2.Location = New System.Drawing.Point(355, 301)
        Me.iconoGestionarInventario__D_2.Name = "iconoGestionarInventario__D_2"
        Me.iconoGestionarInventario__D_2.Size = New System.Drawing.Size(29, 24)
        Me.iconoGestionarInventario__D_2.TabIndex = 15
        Me.iconoGestionarInventario__D_2.TabStop = False
        '
        'iconoGenerarPreLista__D_1
        '
        Me.iconoGenerarPreLista__D_1.IconChar = FontAwesome.Sharp.IconChar.Plus
        Me.iconoGenerarPreLista__D_1.IconColor = System.Drawing.Color.White
        Me.iconoGenerarPreLista__D_1.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoGenerarPreLista__D_1.IconSize = 29
        Me.iconoGenerarPreLista__D_1.Location = New System.Drawing.Point(404, 355)
        Me.iconoGenerarPreLista__D_1.Name = "iconoGenerarPreLista__D_1"
        Me.iconoGenerarPreLista__D_1.Size = New System.Drawing.Size(29, 35)
        Me.iconoGenerarPreLista__D_1.TabIndex = 16
        Me.iconoGenerarPreLista__D_1.TabStop = False
        '
        'iconoGenerarPreLista__D_2
        '
        Me.iconoGenerarPreLista__D_2.IconChar = FontAwesome.Sharp.IconChar.ListCheck
        Me.iconoGenerarPreLista__D_2.IconColor = System.Drawing.Color.White
        Me.iconoGenerarPreLista__D_2.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.iconoGenerarPreLista__D_2.IconSize = 29
        Me.iconoGenerarPreLista__D_2.Location = New System.Drawing.Point(538, 355)
        Me.iconoGenerarPreLista__D_2.Name = "iconoGenerarPreLista__D_2"
        Me.iconoGenerarPreLista__D_2.Size = New System.Drawing.Size(29, 35)
        Me.iconoGenerarPreLista__D_2.TabIndex = 17
        Me.iconoGenerarPreLista__D_2.TabStop = False
        '
        'menuDueno
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.Disable
        Me.BackColor = System.Drawing.Color.Black
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(814, 541)
        Me.Controls.Add(Me.iconoGenerarPreLista__D_2)
        Me.Controls.Add(Me.iconoGenerarPreLista__D_1)
        Me.Controls.Add(Me.iconoGestionarInventario__D_2)
        Me.Controls.Add(Me.iconoGestionarInventario__D_1)
        Me.Controls.Add(Me.iconoGestionarUsuario_2)
        Me.Controls.Add(Me.iconoGestionarUsuario_1)
        Me.Controls.Add(Me.iconoPuntoVenta_D_2)
        Me.Controls.Add(Me.IconPictureBox1)
        Me.Controls.Add(Me.iconoPuntoVenta_D_1)
        Me.Controls.Add(Me.botonRegresar_D_L0)
        Me.Controls.Add(Me.tituloMenuDueno)
        Me.Controls.Add(Me.botonGenerarPrelistaDeProductos_D)
        Me.Controls.Add(Me.botonGestionarInventario_D)
        Me.Controls.Add(Me.botonGestionarUsuario_D)
        Me.Controls.Add(Me.botonPuntoDeVenta_D)
        Me.Name = "menuDueno"
        Me.Text = "MENU DUEÑO"
        CType(Me.iconoPuntoVenta_D_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IconPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconoPuntoVenta_D_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconoGestionarUsuario_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconoGestionarUsuario_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconoGestionarInventario__D_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconoGestionarInventario__D_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconoGenerarPreLista__D_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconoGenerarPreLista__D_2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents botonPuntoDeVenta_D As Button
    Friend WithEvents botonGestionarUsuario_D As Button
    Friend WithEvents botonGestionarInventario_D As Button
    Friend WithEvents botonGenerarPrelistaDeProductos_D As Button
    Friend WithEvents botonRegresar_D_L0 As Button
    Friend WithEvents tituloMenuDueno As Label
    Friend WithEvents iconoPuntoVenta_D_1 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents IconPictureBox1 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents iconoPuntoVenta_D_2 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents iconoGestionarUsuario_1 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents iconoGestionarUsuario_2 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents iconoGestionarInventario__D_1 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents iconoGestionarInventario__D_2 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents iconoGenerarPreLista__D_1 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents iconoGenerarPreLista__D_2 As FontAwesome.Sharp.IconPictureBox
End Class
