﻿Public Class GESTIONAR_USUARIO
    Private Sub etiquetaApellidoPaterno_Click(sender As Object, e As EventArgs) Handles etiquetaApellidoPaternoUsuario.Click

    End Sub
End Class