﻿Public Class gestionarUsuario
    Private Sub etiquetaApellidoPaterno_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub
End Class