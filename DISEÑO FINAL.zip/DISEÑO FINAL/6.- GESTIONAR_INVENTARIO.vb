﻿Public Class gestionarInventario
    Private Sub gestionarInventario_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class