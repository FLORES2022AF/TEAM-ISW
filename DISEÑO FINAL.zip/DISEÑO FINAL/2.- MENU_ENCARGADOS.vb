﻿Public Class menuEncargado
    Private Sub MENU_ENCARGADOS_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub botonPuntoDeVenta_E_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub iconoPuntoVenta_E_1_Click(sender As Object, e As EventArgs) Handles iconoPuntoVenta_E_2.Click

    End Sub
End Class