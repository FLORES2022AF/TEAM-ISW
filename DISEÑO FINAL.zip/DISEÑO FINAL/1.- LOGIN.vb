﻿Public Class login
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles etiquetaContrasena.Click

    End Sub

    Private Sub ingreseUsuario_TextChanged(sender As Object, e As EventArgs) Handles ingreseUsuario.TextChanged

    End Sub

    Private Sub LOGIN_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub usuario_Click(sender As Object, e As EventArgs) Handles etiquetaUsuario.Click

    End Sub

    Private Sub contraseña_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) 

    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles buscarArt.Click

    End Sub
End Class
